import Hero from './components/Hero';
import WhatYouGet from './components/WhatYouGet';
import WhyWorkWithMe from './components/WhyWorkWithMe';
import HowItWorks from './components/HowItWorks';
import Results from './components/Results';
import Packages from './components/Packages';
import FAQ from './components/FAQ';
import FinalCTA from './components/FinalCTA';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-black text-white">
      <Hero />
      <WhatYouGet />
      <WhyWorkWithMe />
      <HowItWorks />
      <Results />
      <Packages />
      <FAQ />
      <FinalCTA />
      <Footer />
    </div>
  );
}

export default App;
