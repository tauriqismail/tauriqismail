import { ArrowRight } from 'lucide-react';

export default function FinalCTA() {
  return (
    <section className="py-20 md:py-32 px-5">
      <div className="max-w-3xl mx-auto text-center">
        <h2 className="text-[38px] md:text-[48px] lg:text-[56px] font-bold leading-[1.1] mb-12 tracking-tight">
          Ready to Start Getting More Paying Customers?
        </h2>

        <a
          href="https://calendly.com/tauriqismail/discovery-call"
          target="_blank"
          rel="noopener noreferrer"
          className="bg-[#0a0a0a] hover:bg-[#1f1f1f] text-white px-8 py-4 rounded-[14px] text-lg font-semibold transition-all duration-300 hover:scale-105 hover:-translate-y-1 inline-flex items-center gap-2 border border-[#1f1f1f]"
        >
          Book Your Free 15-Min Audit Call
          <ArrowRight className="w-5 h-5" />
        </a>
      </div>
    </section>
  );
}
