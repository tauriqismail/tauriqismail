import { X, Check, AlertCircle } from 'lucide-react';

export default function WhyWorkWithMe() {
  const problems = [
    'Money wasted on ads that do not turn into customers',
    'Leads coming in but no follow-up',
    'Growth relying only on referrals',
  ];

  const solutions = [
    'I fix the system behind all three. You focus on running your business.',
    'I stay involved and keep improving it until it works.',
    'This is not a one-time service — I work with you until it makes sense.',
  ];

  return (
    <section className="py-20 md:py-32 px-5 bg-[#0a0a0a]">
      <div className="max-w-4xl mx-auto">
        <h2 className="text-xs md:text-sm font-bold tracking-[0.2em] text-[#bfbfbf] mb-12 text-center uppercase">
          Why Businesses Work With Me
        </h2>

        <div className="grid md:grid-cols-2 gap-8 mb-12">
          <div className="space-y-4">
            <h3 className="text-lg font-bold mb-6 text-[#ef4444]">Common Problems</h3>
            {problems.map((problem, index) => (
              <div key={index} className="flex items-start gap-3">
                <X className="w-5 h-5 text-[#ef4444] shrink-0 mt-1" />
                <p className="text-[#bfbfbf]">{problem}</p>
              </div>
            ))}
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-bold mb-6 text-[#22c55e]">My Solutions</h3>
            {solutions.map((solution, index) => (
              <div key={index} className="flex items-start gap-3">
                <Check className="w-5 h-5 text-[#22c55e] shrink-0 mt-1" />
                <p className="text-[#bfbfbf]">{solution}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-[#000000] border border-[#1f1f1f] p-6 md:p-8 rounded-[16px]">
          <div className="flex items-start gap-4">
            <AlertCircle className="w-6 h-6 text-[#bfbfbf] shrink-0 mt-1" />
            <div className="space-y-3">
              <p className="text-[#bfbfbf] leading-relaxed">
                This system is not for startups, experiments, or businesses without capacity to take on new customers.
              </p>
              <p className="text-[#bfbfbf] leading-relaxed">
                We work with a limited number of service businesses that are ready to grow and can handle incoming enquiries.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
