import { Search, TrendingUp, Bot } from 'lucide-react';

export default function WhatYouGet() {
  const services = [
    {
      icon: Search,
      title: 'SEO',
      description: 'Helps the right people find you on Google when they are already searching for what you offer. Can be done on its own or as part of a bigger system.',
    },
    {
      icon: TrendingUp,
      title: 'Paid Ads',
      description: 'Brings immediate attention from people ready to take action — not just clicks. Can be run separately or combined with SEO and automation.',
    },
    {
      icon: Bot,
      title: 'AI Automation',
      description: 'Follows up, responds, and reminds automatically so no lead is missed. Works on its own or together with traffic and conversion.',
    },
  ];

  return (
    <section className="py-20 md:py-32 px-5">
      <div className="max-w-5xl mx-auto">
        <h2 className="text-xs md:text-sm font-bold tracking-[0.2em] text-[#bfbfbf] mb-12 text-center uppercase">
          What You Get
        </h2>

        <div className="grid gap-6 mb-12">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <div
                key={index}
                className="bg-[#0a0a0a] border border-[#1f1f1f] p-8 rounded-[16px] transition-all duration-300 hover:scale-[1.02] hover:-translate-y-1"
              >
                <div className="flex items-start gap-4">
                  <div className="bg-[#22c55e]/10 p-3 rounded-[12px] shrink-0">
                    <Icon className="w-6 h-6 text-[#22c55e]" />
                  </div>
                  <div>
                    <h3 className="text-xl md:text-2xl font-bold mb-3">{service.title}</h3>
                    <p className="text-[#bfbfbf] text-base md:text-lg leading-relaxed">
                      {service.description}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        <p className="text-center text-[#bfbfbf] text-base md:text-lg">
          Each service works on its own — but performs best when connected.
        </p>
      </div>
    </section>
  );
}
