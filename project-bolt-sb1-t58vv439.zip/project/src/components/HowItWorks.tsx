export default function HowItWorks() {
  const steps = [
    {
      number: '1',
      title: 'Free Audit Call',
      description: 'Understand your business',
    },
    {
      number: '2',
      title: 'System Setup / Onboarding',
      description: 'Access and instructions',
    },
    {
      number: '3',
      title: 'Execution',
      description: 'Implement traffic, automation, follow-up',
    },
    {
      number: '4',
      title: 'Continuous Improvement',
      description: 'Refine until results',
    },
  ];

  return (
    <section className="py-20 md:py-32 px-5">
      <div className="max-w-4xl mx-auto">
        <h2 className="text-xs md:text-sm font-bold tracking-[0.2em] text-[#bfbfbf] mb-12 text-center uppercase">
          How This Works
        </h2>

        <div className="grid gap-6">
          {steps.map((step, index) => (
            <div
              key={index}
              className="bg-[#0a0a0a] border border-[#1f1f1f] p-6 md:p-8 rounded-[16px] transition-all duration-300 hover:scale-[1.02] hover:-translate-y-1"
            >
              <div className="flex items-start gap-6">
                <div className="bg-[#22c55e]/10 text-[#22c55e] w-12 h-12 rounded-full flex items-center justify-center font-bold text-xl shrink-0">
                  {step.number}
                </div>
                <div>
                  <h3 className="text-xl md:text-2xl font-bold mb-2">{step.title}</h3>
                  <p className="text-[#bfbfbf] text-base md:text-lg">{step.description}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
