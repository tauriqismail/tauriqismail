export default function Footer() {
  return (
    <footer className="py-12 px-5 border-t border-[#1f1f1f] bg-[#0a0a0a]">
      <div className="max-w-5xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-center gap-6">
          <p className="text-[#bfbfbf] text-sm">
            © 2026 Tauriq Ismail. All rights reserved
          </p>
          <a
            href="mailto:connect@tauriqismail.com"
            className="text-[#bfbfbf] hover:text-white text-sm transition-colors"
          >
            connect@tauriqismail.com
          </a>
        </div>
      </div>
    </footer>
  );
}
