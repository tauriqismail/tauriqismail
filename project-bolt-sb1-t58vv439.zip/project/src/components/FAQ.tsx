import { useState } from 'react';
import { ChevronDown } from 'lucide-react';

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const faqs = [
    {
      question: 'Can I start with just one service?',
      answer: 'Yes, you can start with any single service. Each service works independently, though they perform best when integrated together as part of a complete system.',
    },
    {
      question: 'How is this different from an agency?',
      answer: 'I stay personally involved throughout the entire process and focus exclusively on results. This is not a one-time project — I work with you continuously until the system works and delivers the results you need.',
    },
    {
      question: 'How long does it take to see results?',
      answer: 'Typically 30–90 days, depending on your industry, current situation, and the service package. Some results like paid ads traffic can be seen immediately, while SEO and automation take longer to mature.',
    },
    {
      question: 'Do you guarantee results?',
      answer: 'Yes. We work with you until the system works and delivers results. If it does not work, you do not pay the remaining 50%. This is not a typical agency model — your success is directly tied to payment.',
    },
  ];

  return (
    <section className="py-20 md:py-32 px-5 bg-[#0a0a0a]">
      <div className="max-w-3xl mx-auto">
        <h2 className="text-xs md:text-sm font-bold tracking-[0.2em] text-[#bfbfbf] mb-12 text-center uppercase">
          Frequently Asked Questions
        </h2>

        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <div
              key={index}
              className="bg-[#000000] border border-[#1f1f1f] rounded-[16px] overflow-hidden transition-all duration-300"
            >
              <button
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
                className="w-full flex items-center justify-between p-6 md:p-8 text-left hover:bg-[#0a0a0a] transition-colors"
              >
                <span className="text-lg md:text-xl font-semibold pr-4">{faq.question}</span>
                <ChevronDown
                  className={`w-5 h-5 text-[#bfbfbf] shrink-0 transition-transform duration-300 ${
                    openIndex === index ? 'rotate-180' : ''
                  }`}
                />
              </button>
              <div
                className={`overflow-hidden transition-all duration-300 ${
                  openIndex === index ? 'max-h-96' : 'max-h-0'
                }`}
              >
                <div className="px-6 md:px-8 pb-6 md:pb-8">
                  <p className="text-[#bfbfbf] leading-relaxed">{faq.answer}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
