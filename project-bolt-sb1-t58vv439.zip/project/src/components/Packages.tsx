export default function Packages() {
  const packages = [
    {
      name: 'Starter',
      description: 'Single service, basic setup & optimization.',
      payment: '50% upfront, 50% on results.',
    },
    {
      name: 'Standard',
      description: 'Full system: SEO + Ads + Automation.',
      payment: '50% upfront, 50% on results.',
      featured: true,
    },
    {
      name: 'Premium',
      description: 'Full system + priority optimization, tracking, and continuous improvement.',
      payment: '50% upfront, 50% on results.',
    },
  ];

  return (
    <section className="py-20 md:py-32 px-5">
      <div className="max-w-5xl mx-auto">
        <h2 className="text-xs md:text-sm font-bold tracking-[0.2em] text-[#bfbfbf] mb-12 text-center uppercase">
          Packages
        </h2>

        <div className="grid md:grid-cols-3 gap-6 mb-12">
          {packages.map((pkg, index) => (
            <div
              key={index}
              className={`bg-[#0a0a0a] border ${
                pkg.featured ? 'border-[#22c55e]' : 'border-[#1f1f1f]'
              } p-8 rounded-[16px] transition-all duration-300 hover:scale-[1.02] hover:-translate-y-1 flex flex-col`}
            >
              <h3 className="text-2xl md:text-3xl font-bold mb-4">{pkg.name}</h3>
              <p className="text-[#bfbfbf] mb-6 flex-grow leading-relaxed">{pkg.description}</p>
              <div className="border-t border-[#1f1f1f] pt-4">
                <p className="text-sm text-[#bfbfbf]">{pkg.payment}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="bg-[#0a0a0a] border border-[#1f1f1f] p-6 md:p-8 rounded-[16px] text-center">
          <p className="text-[#bfbfbf] text-base md:text-lg">
            <span className="font-semibold text-white">Guarantee reminder:</span> We work with you until it works or you don't pay.
          </p>
        </div>
      </div>
    </section>
  );
}
