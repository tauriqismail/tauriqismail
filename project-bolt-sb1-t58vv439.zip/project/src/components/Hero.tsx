import { ArrowRight } from 'lucide-react';

export default function Hero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: "url('/Screenshot_2026-03-05_at_14.43.20.png')" }}
      />
      <div className="absolute inset-0 bg-black/70" />

      <div className="relative z-10 w-full max-w-4xl mx-auto px-5 py-20 text-center">
        <h1 className="text-[38px] md:text-[56px] lg:text-[64px] font-bold leading-[1.1] mb-6 tracking-tight">
          I Help Service Businesses Get More Paying Customers Consistently
        </h1>

        <p className="text-[#bfbfbf] text-lg md:text-xl mb-10 tracking-wide">
          We work with you until it works or you don't pay.
        </p>

        <a
          href="https://calendly.com/tauriqismail/discovery-call"
          target="_blank"
          rel="noopener noreferrer"
          className="bg-[#0a0a0a] hover:bg-[#1f1f1f] text-white px-8 py-4 rounded-[14px] text-lg font-semibold transition-all duration-300 hover:scale-105 hover:-translate-y-1 inline-flex items-center gap-2 border border-[#1f1f1f]"
        >
          Book Your Free 15-Min Audit Call
          <ArrowRight className="w-5 h-5" />
        </a>

        <div className="mt-12 flex flex-col sm:flex-row gap-4 justify-center items-center">
          <div className="bg-[#0a0a0a] border border-[#1f1f1f] px-6 py-3 rounded-[14px]">
            <p className="text-sm text-[#bfbfbf]">5+ Businesses Helped</p>
          </div>
          <div className="bg-[#0a0a0a] border border-[#1f1f1f] px-6 py-3 rounded-[14px]">
            <p className="text-sm text-[#bfbfbf]">Results in 30–90 Days</p>
          </div>
          <div className="bg-[#0a0a0a] border border-[#1f1f1f] px-6 py-3 rounded-[14px]">
            <p className="text-sm text-[#bfbfbf]">Client Acquisition System Tested</p>
          </div>
        </div>
      </div>
    </section>
  );
}
