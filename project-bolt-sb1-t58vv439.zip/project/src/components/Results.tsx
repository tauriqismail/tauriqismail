import { X, Check, ArrowRight } from 'lucide-react';

export default function Results() {
  const comparisons = [
    {
      category: 'Leads',
      before: 'Random, inconsistent',
      after: 'Predictable and automated',
    },
    {
      category: 'Follow-Up',
      before: 'Manual / missing',
      after: 'Automated, never missed',
    },
    {
      category: 'Ads & Campaigns',
      before: 'Wasted budget',
      after: 'Paid campaigns convert leads',
    },
    {
      category: 'Growth',
      before: 'Stuck / referral-only',
      after: 'Scalable & repeatable',
    },
  ];

  return (
    <section className="py-20 md:py-32 px-5 bg-[#0a0a0a]">
      <div className="max-w-4xl mx-auto">
        <h2 className="text-xs md:text-sm font-bold tracking-[0.2em] text-[#bfbfbf] mb-12 text-center uppercase">
          Results
        </h2>

        <div className="space-y-6">
          {comparisons.map((comparison, index) => (
            <div
              key={index}
              className="bg-[#000000] border border-[#1f1f1f] p-6 md:p-8 rounded-[16px]"
            >
              <h3 className="text-lg md:text-xl font-bold mb-6">{comparison.category}</h3>
              <div className="flex flex-col md:flex-row items-start md:items-center gap-6">
                <div className="flex items-start gap-3 flex-1">
                  <X className="w-5 h-5 text-[#ef4444] shrink-0 mt-1" />
                  <p className="text-[#bfbfbf]">{comparison.before}</p>
                </div>

                <ArrowRight className="w-6 h-6 text-[#bfbfbf] shrink-0 hidden md:block" />

                <div className="flex items-start gap-3 flex-1">
                  <Check className="w-5 h-5 text-[#22c55e] shrink-0 mt-1" />
                  <p className="text-[#bfbfbf]">{comparison.after}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
